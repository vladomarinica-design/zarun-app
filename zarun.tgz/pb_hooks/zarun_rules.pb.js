/// <reference path="../pb_data/types.d.ts" />
// Pri každom ďalšom štarte (pri prvom ich nastaví migrácia) nastaví, kto má do ZARUN prístup.
// Mentor (ZARUN_MENTOR_EMAIL) aj bežkyňa (ZARUN_RUNNER_EMAIL) vidia a zapisujú tréningy.
// Odporúčania a dátum začiatku plánu mení iba mentor. Ktokoľvek iný síce môže mať účet, ale nič nevidí.
onBootstrap((e) => {
  e.next();
  try {

  const clean = (v) => String(v || "").trim().toLowerCase().replace(/["'\\]/g, "");
  const mentor = clean($os.getenv("ZARUN_MENTOR_EMAIL"));
  const runner = clean($os.getenv("ZARUN_RUNNER_EMAIL"));

  const emails = [mentor, runner].filter(Boolean);
  const member = emails.length
    ? "(" + emails.map((m) => `@request.auth.email = "${m}"`).join(" || ") + ")"
    : "id = 'nikto'";
  const onlyMentor = mentor ? `@request.auth.email = "${mentor}"` : "id = 'nikto'";

  const set = (name, read, write) => {
    const c = e.app.findCollectionByNameOrId(name);
    c.listRule = read; c.viewRule = read;
    c.createRule = write; c.updateRule = write; c.deleteRule = write;
    e.app.save(c);
  };
  set("logs", member, member);
  set("notes", member, onlyMentor);
  set("config", member, onlyMentor);

  console.log(`[zarun] prístup: mentor=${mentor || "-"} bežkyňa=${runner || "-"}`);
  } catch (err) {
    console.log("[zarun] pravidlá sa nepodarilo nastaviť: " + err);
  }
});

// Verejný endpoint, aby appka vedela, či je prihlásený mentor alebo bežkyňa.
routerAdd("GET", "/api/zarun/role", (e) => {
  const auth = e.auth;
  if (!auth) return e.json(200, { role: "none" });
  const email = String(auth.email() || "").toLowerCase();
  const mentor = String($os.getenv("ZARUN_MENTOR_EMAIL") || "").trim().toLowerCase();
  const runner = String($os.getenv("ZARUN_RUNNER_EMAIL") || "").trim().toLowerCase();
  const role = email && email === mentor ? "mentor" : email && email === runner ? "runner" : "none";
  return e.json(200, { role });
});
