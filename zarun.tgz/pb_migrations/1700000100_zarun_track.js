/// <reference path="../pb_data/types.d.ts" />
// ZARUN – pridá k tréningom GPS trasu z hodiniek (zoznam bodov [lat, lon]).
migrate((app) => {
  const logs = app.findCollectionByNameOrId("logs");
  if (!logs.fields.getByName("track")) {
    logs.fields.add(new JSONField({ name: "track", maxSize: 2000000 }));
    app.save(logs);
  }
}, (app) => {
  const logs = app.findCollectionByNameOrId("logs");
  logs.fields.removeByName("track");
  app.save(logs);
});
