/// <reference path="../pb_data/types.d.ts" />
// ZARUN – vytvorí kolekcie pre tréningy, odporúčania mentora a nastavenia.
// Pravidlá prístupu (kto čo vidí) sa berú zo súboru .env; pri ďalších štartoch ich obnoví pb_hooks/zarun_rules.pb.js.
migrate((app) => {
  const users = app.findCollectionByNameOrId("users");
  users.createRule = ""; // registrácia povolená; dáta uvidia len e-maily z .env
  app.save(users);

  const clean = (v) => String(v || "").trim().toLowerCase().replace(/["'\\]/g, "");
  const mentor = clean($os.getenv("ZARUN_MENTOR_EMAIL"));
  const runner = clean($os.getenv("ZARUN_RUNNER_EMAIL"));
  const emails = [mentor, runner].filter(Boolean);
  const MEMBER = emails.length
    ? "(" + emails.map((m) => `@request.auth.email = "${m}"`).join(" || ") + ")"
    : "id = 'nikto'";
  const MENTOR = mentor ? `@request.auth.email = "${mentor}"` : "id = 'nikto'";

  const logs = new Collection({
    type: "base",
    name: "logs",
    listRule: MEMBER, viewRule: MEMBER, createRule: MEMBER, updateRule: MEMBER, deleteRule: MEMBER,
    fields: [
      { name: "sid", type: "text", required: true, max: 20 },
      { name: "done", type: "bool" },
      { name: "date", type: "text", max: 20 },
      { name: "km", type: "text", max: 20 },
      { name: "time", type: "text", max: 20 },
      { name: "hr", type: "text", max: 10 },
      { name: "rpe", type: "text", max: 5 },
      { name: "nonstop", type: "bool" },
      { name: "note", type: "text", max: 2000 },
      { name: "author", type: "text", max: 200 },
      { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
    ],
    indexes: ["CREATE UNIQUE INDEX idx_logs_sid ON logs (sid)"],
  });
  app.save(logs);

  const notes = new Collection({
    type: "base",
    name: "notes",
    listRule: MEMBER, viewRule: MEMBER, createRule: MENTOR, updateRule: MENTOR, deleteRule: MENTOR,
    fields: [
      { name: "sid", type: "text", required: true, max: 20 },
      { name: "text", type: "text", max: 4000 },
      { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
    ],
    indexes: ["CREATE UNIQUE INDEX idx_notes_sid ON notes (sid)"],
  });
  app.save(notes);

  const config = new Collection({
    type: "base",
    name: "config",
    listRule: MEMBER, viewRule: MEMBER, createRule: MENTOR, updateRule: MENTOR, deleteRule: MENTOR,
    fields: [
      { name: "key", type: "text", required: true, max: 50 },
      { name: "value", type: "text", max: 2000 },
    ],
    indexes: ["CREATE UNIQUE INDEX idx_config_key ON config (key)"],
  });
  app.save(config);

  const rec = new Record(config);
  rec.set("key", "startDate");
  rec.set("value", "2026-11-21");
  app.save(rec);
}, (app) => {
  for (const n of ["logs", "notes", "config"]) {
    try { app.delete(app.findCollectionByNameOrId(n)); } catch (_) {}
  }
});
